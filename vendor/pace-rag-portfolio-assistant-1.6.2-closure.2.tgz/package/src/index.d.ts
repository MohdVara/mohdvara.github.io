import type { ComponentType } from "react";
export interface AssistantProps {
  semanticMessages?: { locale: string; lexical: string; improving: string; available: string; unavailable: string; cancelled: string; deferred: string; improve: string; retry: string; cancel: string };
  scopeId?: "professional" | "implementation" | "fictional";
  libraryExternal?: boolean;
  presentation?: "lab" | "portfolio";
  starterQuestions?: readonly string[];
  onKnowledgeFreshness?: (info: {snapshotId:string; sourceFingerprint:string; indexedAt:string|null; checkedAt:string|null; artifactBuiltAt:string|null; sourceCount:number; preview:boolean} | null) => void;
  onPublicationReady?: (ready: boolean) => void;
  corpusId?: "portfolio" | "lab";
  labUrl?: string;
  assetBase?: string;
  onClose?: () => void;
  lab?: boolean;
  live?: { apiBase: string; turnstileSiteKey: string; verified?: true };
}
declare const Assistant: ComponentType<AssistantProps>;
export default Assistant;
